package unifor.pagamento.pagamento.model;

public enum FormaDePagamento {
    CARTAO,    // Pagamento com cartão (crédito ou débito)
    PIX        // Pagamento via PIX
}
