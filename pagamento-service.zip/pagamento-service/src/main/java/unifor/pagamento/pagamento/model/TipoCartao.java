package unifor.pagamento.pagamento.model;

public enum TipoCartao {
    CREDITO,
    DEBITO
} 