package unifor.pagamento.pagamento.exception;
//Classe para tratar exceções de pagamento
public class PagamentoException extends RuntimeException {
    
    public PagamentoException(String message) {
        super(message);
    }
} 