import styles from './Logo.module.css';

export const Logo = () => (
  <img src="/img/loter_Logo.png" alt="Logo Loter" className={styles.logo} />
);